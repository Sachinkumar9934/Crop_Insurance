<?php
    include 'C:/xampp/htdocs/crop_insurance/config/db_connect.php';
    include 'C:/xampp/htdocs/crop_insurance/config/config.php';
    //echo ($_SESSION['user_farmer_id']);
    header("Location: views/Homepage.php");
?>
